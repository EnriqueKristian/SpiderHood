﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace SpiderHood.Models
{
    public class Category
    {
        public Guid IdCategory { get; set; }

        [Required(ErrorMessage = "La descripción es obligatorio")]
        public string Description { get; set; } = null!;

        [Required(ErrorMessage = "La Descripción Corta es obligatorio")]
        public string ShortDescript { get; set; } = null!;
        //public Guid IdOwner { get; set; }
        public Guid IdBuilding { get; set; }
        public Guid ParentId { get; set; }

        [Required(ErrorMessage = "Selecciona un icono.")]
        public string Icon { get; set; } = null!;

        [Required(ErrorMessage = "Selecciona un color.")]
        [RegularExpression("^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$", ErrorMessage = "Color inválido.")]
        public string Color { get; set; } = null!;

        public string Ruta { get; set; } = null!;
        public string ParentName { get; set; } = null!;
        public int Nivel { get; set; }
        // Identifica la sección del presupuesto (ver Database/Scripts view_categories):
        // los hijos heredan el Sort de su categoría raíz por la recursión de esa vista, así
        // que sólo importa que cada categoría RAÍZ (Nivel == 0) tenga un valor único por
        // edificio -- si dos raíces comparten Sort, GET_BudgetDetailDefault las colapsa en
        // una sola sección (ver CategoryPage.AddItem).
        public int Sort { get; set; }
        public TypeDistribution Distribution { get; set; } = TypeDistribution.Fija;
        // Solo aplica a categorías raíz (Nivel == 0, una sección del recibo). Controla
        // únicamente el PDF del recibo de mantenimiento (InstallmentExportService): si es
        // false, esa sección se imprime colapsada (nombre + subtotal, sin desglosar cada
        // ítem) — el "Ver Detalle" en pantalla (InstallmentDetailModal) no se ve afectado,
        // siempre muestra el desglose completo. Columna agregada por
        // Database/Migrations/2026-08-27f_Category_ShowDetailInReceipt.sql.
        public bool ShowDetailInReceipt { get; set; } = true;
    }


    public interface IRepository<T> where T : class
    {
        Task AddAsync(T entity);
        Task<T> GetByIdAsync(Guid id);
        Task<IEnumerable<T>> GetAllAsync();
        void Update(T entity);
        void Remove(T entity);
    }

    public interface IUnitOfWork : IDisposable
    {
        IRepository<Category> Categories { get; }
        IRepository<BudgetHeader> BudgetHeaders { get; }
        IRepository<BudgetDetail> ExpenseItems { get; }
        Task<int> CompleteAsync();
    }


    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly DbContext _context;
        private readonly DbSet<T> _dbSet;

        public Repository(DbContext context)
        {
            _context = context;
            _dbSet = context.Set<T>();
        }

        public async Task AddAsync(T entity) => await _dbSet.AddAsync(entity);
        public async Task<T> GetByIdAsync(Guid id) => await _dbSet.FindAsync(id);
        public async Task<IEnumerable<T>> GetAllAsync() => await _dbSet.ToListAsync();
        public void Update(T entity) => _dbSet.Update(entity);
        public void Remove(T entity) => _dbSet.Remove(entity);
    }


    public class UnitOfWork : IUnitOfWork
    {
        private readonly DbContext _context;

        public IRepository<Category> Categories { get; }
        public IRepository<BudgetHeader> BudgetHeaders { get; }
        public IRepository<BudgetDetail> ExpenseItems { get; }

        public UnitOfWork(DbContext context)
        {
            _context = context;
            Categories = new Repository<Category>(context);
            BudgetHeaders = new Repository<BudgetHeader>(context);
            ExpenseItems = new Repository<BudgetDetail>(context);
        }

        public async Task<int> CompleteAsync() => await _context.SaveChangesAsync();

        public void Dispose() => _context.Dispose();
    }


}
