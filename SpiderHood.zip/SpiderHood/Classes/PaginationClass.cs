﻿using SpiderHood.Models;

namespace SpiderHood.Utilities
{
    public class PaginationClass<T> where T : class
    {
        // Propiedades públicas
        public int CurrentPage { get; private set; } = 1;
        public int PageSize { get; private set; } = 25;
        public int TotalPages { get; private set; } = 0;
        public int TotalRecords { get; private set; } = 0;
        public int StartRecord { get; private set; } = 0;
        public int EndRecord { get; private set; } = 0;
        public List<T> CurrentPageData { get; private set; } = new();
        public List<T> AllData { get; set; } = new();
        public List<T> FilteredData { get; private set; } = new();
        public string SortColumn { get; private set; } = string.Empty;
        public bool SortAscending { get; private set; } = true;
        public string SearchTerm { get; private set; } = string.Empty;

        // Configuraciones
        private Dictionary<string, string> _filterOptions = new();
        private Dictionary<string, Func<T, object>> _sortExpressions = new();
        private string _defaultSortColumn = string.Empty;
        private bool _defaultSortAscending = true;
        private Func<T, bool> _customFilter = null;

        // Eventos
        public event Action OnPaginationChanged;

        // Constructores
        public PaginationClass()
        {
            // Constructor por defecto
        }

        public PaginationClass(
            Dictionary<string, string> filterOptions,
            Dictionary<string, Func<T, object>> sortExpressions,
            string defaultSortColumn = "",
            bool defaultSortAscending = true)
        {
            InitializeConfiguration(filterOptions, sortExpressions, defaultSortColumn, defaultSortAscending);
        }

        // Método para inicializar configuración
        public void InitializeConfiguration(
            Dictionary<string, string> filterOptions,
            Dictionary<string, Func<T, object>> sortExpressions,
            string defaultSortColumn = "",
            bool defaultSortAscending = true)
        {
            _filterOptions = filterOptions ?? new Dictionary<string, string>();
            _sortExpressions = sortExpressions ?? new Dictionary<string, Func<T, object>>();
            _defaultSortColumn = defaultSortColumn;
            _defaultSortAscending = defaultSortAscending;

            if (!string.IsNullOrEmpty(_defaultSortColumn) && !_sortExpressions.ContainsKey(_defaultSortColumn))
            {
                throw new ArgumentException($"La columna de ordenamiento por defecto '{_defaultSortColumn}' no está en las expresiones de ordenamiento.");
            }
        }

        // Inicializar con datos
        public void Initialize(List<T> data = null)
        {
            if (data != null)
            {
                AllData = data;
            }

            CurrentPage = 1;
            ApplyFilterAndSort();
            UpdatePagination();
            NotifyChange();
        }

        // Método principal para aplicar filtros y ordenamiento
        private void ApplyFilterAndSort()
        {
            if (!AllData.Any())
            {
                FilteredData = new List<T>();
                return;
            }

            // Aplicar filtro personalizado
            var filtered = _customFilter != null
                ? AllData.Where(_customFilter).ToList()
                : AllData.ToList();

            // Aplicar búsqueda
            if (!string.IsNullOrWhiteSpace(SearchTerm))
            {
                filtered = ApplySearch(filtered, SearchTerm);
            }

            FilteredData = filtered;

            // Aplicar ordenamiento
            if (!string.IsNullOrWhiteSpace(SortColumn) && _sortExpressions.ContainsKey(SortColumn))
            {
                var sortExpression = _sortExpressions[SortColumn];
                FilteredData = SortAscending
                    ? FilteredData.OrderBy(sortExpression).ToList()
                    : FilteredData.OrderByDescending(sortExpression).ToList();
            }
            else if (!string.IsNullOrWhiteSpace(_defaultSortColumn) &&
                     _sortExpressions.ContainsKey(_defaultSortColumn))
            {
                var defaultSort = _sortExpressions[_defaultSortColumn];
                FilteredData = _defaultSortAscending
                    ? FilteredData.OrderBy(defaultSort).ToList()
                    : FilteredData.OrderByDescending(defaultSort).ToList();
            }
        }

        // Método virtual para búsqueda (puede ser sobrescrito)
        protected virtual List<T> ApplySearch(List<T> data, string searchTerm)
        {
            // Implementación por defecto - buscar en todos los campos string
            return data.Where(item =>
                item.ToString().Contains(searchTerm, StringComparison.OrdinalIgnoreCase)
            ).ToList();
        }

        // Actualizar paginación
        private void UpdatePagination()
        {
            TotalRecords = FilteredData.Count;
            TotalPages = (int)Math.Ceiling((double)TotalRecords / PageSize);

            // Ajustar página actual
            if (CurrentPage > TotalPages && TotalPages > 0)
            {
                CurrentPage = TotalPages;
            }
            else if (CurrentPage < 1 && TotalPages > 0)
            {
                CurrentPage = 1;
            }

            // Calcular registros
            StartRecord = TotalRecords > 0 ? ((CurrentPage - 1) * PageSize) + 1 : 0;
            EndRecord = Math.Min(CurrentPage * PageSize, TotalRecords);

            // Obtener datos de la página actual
            CurrentPageData = FilteredData
                .Skip((CurrentPage - 1) * PageSize)
                .Take(PageSize)
                .ToList();
        }

        // Métodos de navegación
        public void GoToPage(int page)
        {
            if (page >= 1 && page <= TotalPages)
            {
                CurrentPage = page;
                UpdatePagination();
                NotifyChange();
            }
        }
        public void GoToFirstPage() => GoToPage(1);
        public void GoToPreviousPage() => GoToPage(CurrentPage - 1);
        public void GoToNextPage() => GoToPage(CurrentPage + 1);
        public void GoToLastPage() => GoToPage(TotalPages);

        // Cambiar tamaño de página
        public void ChangePageSize(int newSize)
        {
            if (newSize > 0)
            {
                PageSize = newSize;
                CurrentPage = 1;
                UpdatePagination();
                NotifyChange();
            }
        }

        // Ordenar por columna
        public void SortByColumn(string column)
        {
            if (_sortExpressions.ContainsKey(column))
            {
                if (SortColumn == column)
                {
                    SortAscending = !SortAscending;
                }
                else
                {
                    SortColumn = column;
                    SortAscending = true;
                }

                ApplyFilterAndSort();
                CurrentPage = 1;
                UpdatePagination();
                NotifyChange();
            }
        }

        // Buscar
        public void Search(string term)
        {
            SearchTerm = term;
            ApplyFilterAndSort();
            CurrentPage = 1;
            UpdatePagination();
            NotifyChange();
        }

        // Aplicar filtro personalizado
        public void ApplyCustomFilter(Func<T, bool> filter)
        {
            _customFilter = filter;
            ApplyFilterAndSort();
            CurrentPage = 1;
            UpdatePagination();
            NotifyChange();
        }

        // Limpiar filtros
        public void ClearFilters()
        {
            _customFilter = null;
            SearchTerm = string.Empty;
            ApplyFilterAndSort();
            CurrentPage = 1;
            UpdatePagination();
            NotifyChange();
        }

        // Obtener opciones de filtro
        public Dictionary<string, string> GetFilterOptions()
        {
            return _filterOptions;
        }

        // Obtener números de página
        public List<int> GetPageNumbers(int maxPagesToShow = 5)
        {
            var pages = new List<int>();

            if (TotalPages <= maxPagesToShow)
            {
                for (int i = 1; i <= TotalPages; i++)
                {
                    pages.Add(i);
                }
            }
            else
            {
                if (CurrentPage <= 3)
                {
                    for (int i = 1; i <= 4; i++) pages.Add(i);
                    pages.Add(-1);
                    pages.Add(TotalPages);
                }
                else if (CurrentPage >= TotalPages - 2)
                {
                    pages.Add(1);
                    pages.Add(-1);
                    for (int i = TotalPages - 3; i <= TotalPages; i++) pages.Add(i);
                }
                else
                {
                    pages.Add(1);
                    pages.Add(-1);
                    for (int i = CurrentPage - 1; i <= CurrentPage + 1; i++) pages.Add(i);
                    pages.Add(-1);
                    pages.Add(TotalPages);
                }
            }

            return pages;
        }

        // Métodos de utilidad
        public string GetPaginationInfo()
        {
            return TotalRecords > 0
                ? $"Mostrando {StartRecord}-{EndRecord} de {TotalRecords} registros"
                : "No hay registros";
        }

        public string GetSortIndicator(string column)
        {
            if (SortColumn == column)
            {
                return SortAscending ? "↑" : "↓";
            }
            return "";
        }

        // Notificar cambios
        private void NotifyChange()
        {
            OnPaginationChanged?.Invoke();
        }
    }

    public static class PaginationFactory
    {
        private static readonly Dictionary<Type, Func<object>> _typeFactories = new();

        static PaginationFactory()
        {
            // Registrar factories para tipos específicos
            _typeFactories[typeof(ServiceReadingDetail)] = () => new WaterReadingPagination();
            _typeFactories[typeof(TransactionBankDetail)] = () => new TransactionBankDetailPagination();
            _typeFactories[typeof(Installment)] = () => new InstallmentPagination();
        }

        public static PaginationClass<T> CreateForType<T>() where T : class
        {
            var type = typeof(T);

            if (_typeFactories.TryGetValue(type, out var factory))
            {
                return factory() as PaginationClass<T>;
            }

            // Crear una instancia genérica si no hay factory específica
            return new PaginationClass<T>();
        }

        public static PaginationClass<T> CreateForType<T>(
            Dictionary<string, string> filterOptions,
            Dictionary<string, Func<T, object>> sortExpressions,
            string defaultSortColumn = "") where T : class
        {
            var pagination = new PaginationClass<T>(
                filterOptions,
                sortExpressions,
                defaultSortColumn);
            return pagination;
        }

        public static void RegisterFactory<T>(Func<PaginationClass<T>> factory) where T : class
        {
            _typeFactories[typeof(T)] = factory;
        }
    }

    public class WaterReadingPagination : PaginationClass<ServiceReadingDetail>
    {
        public WaterReadingPagination() : base()
        {
            // Configurar opciones específicas para lecturas de agua
            var filterOptions = new Dictionary<string, string>
        {
            { "all", "Todas las lecturas" },
            { "processed", "Procesadas" },
            { "unprocessed", "Sin procesar" },
            { "minimum", "Consumo mínimo" },
            { "error", "Con errores" }
        };

            var sortExpressions = new Dictionary<string, Func<ServiceReadingDetail, object>>
        {
            { "GroupNumber", x => x.GroupNumber },
            { "Consumption", x => x.Consumption },
            { "ReadingDate", x => x.ReadingDate },
            { "CalculatedAmount", x => x.CalculatedAmount },
            { "Procesed", x => x.Procesed }
        };

            // Inicializar configuración usando el método de la clase base
            InitializeConfiguration(filterOptions, sortExpressions, "GroupNumber");
        }

        // Sobrescribir búsqueda para lecturas de agua
        protected override List<ServiceReadingDetail> ApplySearch(List<ServiceReadingDetail> data, string searchTerm)
        {
            return data.Where(item => (item.GroupNumber.ToString().Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
            ).ToList();
        }

        // Métodos específicos para lecturas de agua
        public void FilterByApartment(string apartmentCode)
        {
            if (string.IsNullOrEmpty(apartmentCode))
            {
                ClearFilters();
            }
            else
            {
                ApplyCustomFilter(x =>
                    !string.IsNullOrEmpty(x.GroupNumber.ToString()) &&
                    x.GroupNumber.ToString().Contains(apartmentCode, StringComparison.OrdinalIgnoreCase));
            }
        }

        public void FilterByProcessingStatus(bool isProcessed)
        {
            ApplyCustomFilter(x => x.Procesed == isProcessed);
        }

        public void FilterByGroupNumber(int? groupNumber)
        {
            if (!groupNumber.HasValue)
            {
                ClearFilters();
            }
            else
            {
                ApplyCustomFilter(x => x.GroupNumber == groupNumber.Value);
            }
        }

        public void FilterMinimumConsumption()
        {
            ApplyCustomFilter(x => x.Minimum);
        }

        public Dictionary<string, string> GetAvailableFilters()
        {
            return GetFilterOptions();
        }
    }

    public class TransactionBankDetailPagination : PaginationClass<TransactionBankDetail>
    {
        public TransactionBankDetailPagination() : base()
        {
            var filterOptions = new Dictionary<string, string>
        {
            { "all", "Todos" },
            { "valid", "Válidos" },
            { "duplicate", "Duplicados" },
            { "error", "Con error" }
        };

            var sortExpressions = new Dictionary<string, Func<TransactionBankDetail, object>>
        {
            { "StatementDate", x => x.StatementDate },
            { "Description", x => x.Description },
            { "ITF", x => x.ITF },
            { "Currency", x => x.Currency },
            { "Amount", x => x.Amount },
            { "Validation", x => x.Validation }
        };

            InitializeConfiguration(filterOptions, sortExpressions, "StatementDate");
        }

        protected override List<TransactionBankDetail> ApplySearch(List<TransactionBankDetail> data, string searchTerm)
        {
            return data.Where(item =>
                (!string.IsNullOrEmpty(item.Description) &&
                 item.Description.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)) ||
                (!string.IsNullOrEmpty(item.Currency) &&
                 item.Currency.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)) ||
                (!string.IsNullOrEmpty(item.Validation) &&
                 item.Validation.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
            ).ToList();
        }

        public void ApplyValidationFilter(string validationType)
        {
            if (validationType == "all")
            {
                ClearFilters();
            }
            else
            {
                ApplyCustomFilter(x =>
                    !string.IsNullOrEmpty(x.Validation) &&
                    x.Validation.Equals(validationType, StringComparison.OrdinalIgnoreCase));
            }
        }
    }

    public class InstallmentPagination : PaginationClass<Installment>
    {
        public InstallmentPagination() : base()
        {
            var filterOptions = new Dictionary<string, string>
        {
            { "all", "Todos" },
            { "valid", "Válidos" },
            { "duplicate", "Duplicados" },
            { "error", "Con error" }
        };

            var sortExpressions = new Dictionary<string, Func<Installment, object>>
        {
            { "UnitName", x => x.UnitName },
            { "OwnerName", x => x.OwnerName },
            { "Period", x => x.Period},
            { "TotalArea", x => x.TotalArea },
            { "Percent", x => x.Percent },
            { "Amount", x => x.Amount },
            { "IsPaid", x => x.IsPaid }
        };

            // Descendente por defecto (más reciente primero) -- ver
            // Docs/Pendientes-Negocio-Migracion.md #6.5: sin esto, ApplyFilterAndSort
            // reordenaba siempre ascendente por Period mientras no hubiera SortColumn
            // elegido a mano, ignorando el OrderByDescending que arma InstallmentList.razor
            // antes de pasarle los datos a Initialize(...).
            InitializeConfiguration(filterOptions, sortExpressions, "Period", defaultSortAscending: false);
        }

        protected override List<Installment> ApplySearch(List<Installment> data, string searchTerm)
        {
            var term = searchTerm.ToLower();

            return data
                .Where(x => x.UnitName.ToLower().Contains(term) ||
                           x.OwnerName.ToLower().Contains(term))
                .ToList();

        }

        public void ApplyStatusFilter(string validationType)
        {
            if (validationType == "all")
            {
                ClearFilters();
            }
            else
            {
                ApplyCustomFilter(x => x.IsPaid);
            }
        }
    }

    // Paginación/orden para "Mis Recibos" (portal del residente) -- a diferencia de
    // InstallmentPagination (pensada para el listado admin, que agrupa por unidad/
    // propietario), acá se ordena/busca por las columnas que ve el residente: el nombre
    // del recibo ("Recibo <Mes-Año> <DPTO>"), período, vencimiento, montos y estado.
    public class ReceiptPagination : PaginationClass<Installment>
    {
        public ReceiptPagination() : base()
        {
            var sortExpressions = new Dictionary<string, Func<Installment, object>>
            {
                { "Name", x => $"Recibo {x.Period:yyyy-MM} {x.UnitName}" },
                { "Period", x => x.Period },
                { "DueDate", x => x.DueDate },
                { "Amount", x => x.Amount },
                { "AmountPaid", x => x.AmountPaid },
                { "Debt", x => x.Debt },
                { "Status", x => EstadoOrden(x) }
            };

            InitializeConfiguration(new Dictionary<string, string>(), sortExpressions, "Period");
        }

        protected override List<Installment> ApplySearch(List<Installment> data, string searchTerm)
        {
            var term = searchTerm.ToLower();

            return data.Where(x =>
                x.UnitName.ToLower().Contains(term) ||
                NombreRecibo(x).ToLower().Contains(term) ||
                x.Period.ToString("MMMM yyyy", new System.Globalization.CultureInfo("es-ES")).ToLower().Contains(term) ||
                (!string.IsNullOrEmpty(x.Concept) && x.Concept.ToLower().Contains(term)) ||
                EstadoTexto(x).ToLower().Contains(term)
            ).ToList();
        }

        public static string NombreRecibo(Installment x)
        {
            var mes = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(
                x.Period.ToString("MMMM", new System.Globalization.CultureInfo("es-ES")));
            return $"Recibo {mes}-{x.Period.Year} {x.UnitName}";
        }

        public static string EstadoTexto(Installment x) => x.Status switch
        {
            ConcilationType.Conciliada => "pagado",
            ConcilationType.Parcial => "parcial",
            _ => x.DueDate.Date < DateTime.Today ? "vencida" : "pendiente de pago"
        };

        private static int EstadoOrden(Installment x) => x.Status switch
        {
            ConcilationType.Conciliada => 0,
            ConcilationType.Parcial => 1,
            _ => x.DueDate.Date < DateTime.Today ? 3 : 2
        };
    }

    public class AccountStatementDetailViewPagination : PaginationClass<AccountStatementDetailView>
    {
        public AccountStatementDetailViewPagination() : base()
        {
            var sortExpressions = new Dictionary<string, Func<AccountStatementDetailView, object>>
        {
            { "StatementDate", x => x.StatementDate },
            { "Description", x => x.Description },
            { "Currency", x => x.Currency },
            { "Amount", x => x.Amount }
        };

            InitializeConfiguration(new Dictionary<string, string>(), sortExpressions, "StatementDate");
        }

        // Búsqueda por transacción (descripción) o monto, tal como indica el placeholder del buscador.
        protected override List<AccountStatementDetailView> ApplySearch(List<AccountStatementDetailView> data, string searchTerm)
        {
            return data.Where(item =>
                (!string.IsNullOrEmpty(item.Description) &&
                 item.Description.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)) ||
                item.Amount.ToString(System.Globalization.CultureInfo.InvariantCulture).Contains(searchTerm, StringComparison.OrdinalIgnoreCase)
            ).ToList();
        }
    }

    public class PeriodPagination : PaginationClass<Models.Period>
    {
        public PeriodPagination() : base()
        {
            var filterOptions = new Dictionary<string, string>
        {
            { "all", "Todos" },
            { "valid", "Válidos" },
            { "duplicate", "Duplicados" },
            { "error", "Con error" }
        };

            var sortExpressions = new Dictionary<string, Func<Models.Period, object>>
        {
            { "Name", x => x.Name },
            { "PeriodType", x => x.PeriodType.ToString() }
        };

            InitializeConfiguration(filterOptions, sortExpressions, "Name");
        }

        protected override List<Models.Period> ApplySearch(List<Models.Period> data, string searchTerm)
        {
            var term = searchTerm.ToLower();

            return data
                .Where(x => x.Name.ToLower().Contains(term))
                .ToList();

        }

        public void ApplyStatusFilter(string validationType)
        {
            if (validationType == "all")
            {
                ClearFilters();
            }
            else
            {
                ApplyCustomFilter(x => x.Status == int.Parse(validationType));
            }
        }

    }

    // Paginación/búsqueda para /buildings (listado de Edificios).
    public class BuildingPagination : PaginationClass<Models.Building>
    {
        public BuildingPagination() : base()
        {
            var sortExpressions = new Dictionary<string, Func<Models.Building, object>>
            {
                { "Number", x => x.Number },
                { "Name", x => x.Name },
                { "Location", x => x.Location }
            };

            InitializeConfiguration(new Dictionary<string, string>(), sortExpressions, "Number");
        }

        protected override List<Models.Building> ApplySearch(List<Models.Building> data, string searchTerm)
        {
            var term = searchTerm.ToLower();

            return data
                .Where(b => (b.Name?.ToLower().Contains(term) ?? false)
                         || (b.Location?.ToLower().Contains(term) ?? false)
                         || b.Number.ToString().Contains(term))
                .ToList();
        }
    }

    // Paginación/orden para /expense (Resumen de Gastos) -- mismo criterio que
    // InstallmentPagination: más reciente primero por defecto.
    // ViewExpense, no Expense -- ver el hallazgo de la sesión del 2026-09-10:
    // Classes/Expense.cs no coincide con ninguna columna real de dbo.Expense,
    // ViewExpense sí (confirmado con INFORMATION_SCHEMA.COLUMNS). Ver
    // IExpenseService.GetExpensesByBuildingAsync.
    public class ExpensePagination : PaginationClass<ViewExpense>
    {
        public ExpensePagination() : base()
        {
            var sortExpressions = new Dictionary<string, Func<ViewExpense, object>>
            {
                { "Description", x => x.Description },
                { "Category", x => x.Category },
                { "ExpenseDate", x => x.ExpenseDate },
                { "Amount", x => x.Amount },
                { "Distribution", x => (object?)x.Distribution ?? string.Empty },
                { "Supplier", x => x.Supplier }
            };

            InitializeConfiguration(new Dictionary<string, string>(), sortExpressions, "ExpenseDate", defaultSortAscending: false);
        }

        protected override List<ViewExpense> ApplySearch(List<ViewExpense> data, string searchTerm)
        {
            var term = searchTerm.ToLower();

            return data.Where(x =>
                (x.Description?.ToLower().Contains(term) ?? false) ||
                (x.Category?.ToLower().Contains(term) ?? false) ||
                (x.Supplier?.ToLower().Contains(term) ?? false)
            ).ToList();
        }
    }

    // Paginación/búsqueda para /comunicados (Docs/Pendientes-Negocio-Consolidado.md #17).
    public class ComunicadoPagination : PaginationClass<Comunicado>
    {
        public ComunicadoPagination() : base()
        {
            var sortExpressions = new Dictionary<string, Func<Comunicado, object>>
            {
                { "Titulo", x => x.Titulo },
                { "CreatedOn", x => x.CreatedOn }
            };

            InitializeConfiguration(new Dictionary<string, string>(), sortExpressions, "CreatedOn", defaultSortAscending: false);
        }

        protected override List<Comunicado> ApplySearch(List<Comunicado> data, string searchTerm)
        {
            var term = searchTerm.ToLower();

            return data.Where(x =>
                x.Titulo.ToLower().Contains(term) ||
                x.Cuerpo.ToLower().Contains(term) ||
                x.CreatedByName.ToLower().Contains(term)
            ).ToList();
        }
    }

    public class ReservaPagination : PaginationClass<Reserva>
    {
        public ReservaPagination() : base()
        {
            var sortExpressions = new Dictionary<string, Func<Reserva, object>>
            {
                { "FechaInicio", x => x.FechaInicio },
                { "NombreAreaComun", x => x.NombreAreaComun },
                { "Estado", x => x.Estado }
            };

            InitializeConfiguration(new Dictionary<string, string>(), sortExpressions, "FechaInicio", defaultSortAscending: false);
        }

        protected override List<Reserva> ApplySearch(List<Reserva> data, string searchTerm)
        {
            var term = searchTerm.ToLower();

            return data.Where(x =>
                x.NombreAreaComun.ToLower().Contains(term) ||
                x.CreatedByName.ToLower().Contains(term) ||
                (x.OrganizadorNombre ?? string.Empty).ToLower().Contains(term)
            ).ToList();
        }
    }
}