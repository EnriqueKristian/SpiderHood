using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SpiderHood.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Text.Json;

namespace SpiderHood.Data
{
    public partial class BDLayout
    {
        #region Add Operations

        public async Task InsertInvitationAsync(InvitationModel invitation, CancellationToken cancellationToken = default)
        {
            await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Invitation,
                    cancellationToken,
                    invitation.IdInvitation,
                    invitation.Code,
                    invitation.Email,
                    invitation.IdBuilding,
                    invitation.BuildingName,
                    invitation.InvitedBy,
                    invitation.Role,
                    invitation.ApartmentNumber,
                    invitation.RequiresApproval,
                    (object?)invitation.AdminMessage ?? DBNull.Value,
                    invitation.ExpirationDate,
                    (object?)invitation.Location ?? DBNull.Value);
                return true;
            }, "InsertInvitation", cancellationToken);
        }

        public async Task<MenuPermissions> AddNewRecordAsync(MenuPermissions item, CancellationToken cancellationToken = default)
        {
            ValidateEntity(item, nameof(item));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_MenuItemPermission,
                    cancellationToken,
                    item.IdMenu!,
                    item.IdRole!);
                return item;
            }, "AddMenuItemPermission", cancellationToken);
        }

        public async Task<MenuItemDefinition> AddNewRecordAsync(MenuItemDefinition item, CancellationToken cancellationToken = default)
        {
            ValidateEntity(item, nameof(item));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_MenuItem,
                    cancellationToken,
                    item.IdMenu!,
                    item.IdParent!,
                    item.ItemKey!,
                    item.Title!,
                    item.Icon!,
                    item.Url!,
                    item.Target!,
                    item.DisplayOrder!,
                    item.IsVisible!,
                    item.BadgeText!,
                    item.BadgeColor!);
                return item;
            }, "AddMenuItem", cancellationToken);
        }

        public async Task<Models.Role> AddNewRecordAsync(Models.Role role, CancellationToken cancellationToken = default)
        {
            ValidateEntity(role, nameof(role));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Role,
                    cancellationToken,
                    role.IdRole,
                    role.RoleName,
                    role.Description,
                    role.IsSystem);
                return role;
            }, "AddRole", cancellationToken);
        }

        public async Task AddUserRoleAsync(Guid idUser, Guid idRole, CancellationToken cancellationToken = default)
        {
            await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_UserRole,
                    cancellationToken,
                    idUser,
                    idRole);
                return true;
            }, "AddUserRole", cancellationToken);
        }

        public async Task AssignUserBuildingRoleAsync(Guid idUser, Guid idBuilding, string role, Guid approvedBy, CancellationToken cancellationToken = default)
        {
            await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_UserBuildingRole,
                    cancellationToken,
                    idUser,
                    idBuilding,
                    role,
                    approvedBy);
                return true;
            }, "AssignUserBuildingRole", cancellationToken);
        }

        // Vincula (o desvincula, con idGroupUnit=null) la unidad de un residente para
        // una asociación usuario-edificio-rol ya existente — ver UPD_UserBuildingUnit.
        // Es lo que permite después filtrar "mis cuotas" (Installment.IdGroupUnit) para
        // ese usuario en Mis Recibos/Mis Deudas y Profile > Finanzas.
        public async Task AssignUnitToUserBuildingAsync(Guid idUser, Guid idBuilding, Guid idRole, Guid? idGroupUnit, CancellationToken cancellationToken = default)
        {
            await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.UPD_UserBuildingUnit,
                    cancellationToken,
                    idUser,
                    idBuilding,
                    idRole,
                    (object?)idGroupUnit);
                return true;
            }, "AssignUnitToUserBuilding", cancellationToken);
        }

        // Aprueba/rechaza una solicitud de acceso puntual -- identificada por su PK
        // completa (IdUser, IdBuilding, IdRole), no sólo IdUser+IdBuilding, para no pisar
        // otras filas del mismo usuario+edificio con otro rol. Ver UPD_UserBuildingApproval.
        public async Task SetUserBuildingApprovalAsync(Guid idUser, Guid idBuilding, Guid idRole, bool isApproved, string status, Guid? approvedBy, CancellationToken cancellationToken = default)
        {
            await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.UPD_UserBuildingApproval,
                    cancellationToken,
                    idUser,
                    idBuilding,
                    idRole,
                    isApproved,
                    status,
                    (object?)approvedBy);
                return true;
            }, "SetUserBuildingApproval", cancellationToken);
        }

        public async Task<Models.RolePermissions> AddNewRecordAsync(Models.RolePermissions permissions, CancellationToken cancellationToken = default)
        {
            ValidateEntity(permissions, nameof(permissions));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_RolePermissions,
                    cancellationToken,
                    permissions.IdRole!,
                    permissions.IdPermission!);
                return permissions;
            }, "AddRolePermissions", cancellationToken);
        }

        public async Task<Models.InstallmentExoneration> AddNewRecordAsync(Models.InstallmentExoneration exoneration, CancellationToken cancellationToken = default)
        {
            ValidateEntity(exoneration, nameof(exoneration));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_InstallmentExoneration,
                    cancellationToken,
                    exoneration.IdBuilding!,
                    exoneration.IdBudgetHeader!);
                return exoneration;
            }, "AddInstallmentExoneration", cancellationToken);
        }

        public async Task<Models.UserModel> AddNewRecordAsync(Models.UserModel user, CancellationToken cancellationToken = default)
        {
            ValidateEntity(user, nameof(user));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_User,
                    cancellationToken,
                    user.IdUser!,
                    user.Email!,
                    user.PasswordHash!,
                    user.FirstName!,
                    user.LastName!,
                    user.PhoneNumber!,
                    user.IsActive);
                return user;
            }, "AddUser", cancellationToken);
        }

        public async Task<Models.InstallmentPaid> AddNewRecordAsync(Models.InstallmentPaid paid, CancellationToken cancellationToken = default)
        {
            ValidateEntity(paid, nameof(paid));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_InstallmentPaid,
                    cancellationToken,
                    paid.IdPaid,
                    paid.IdInstallment,
                    paid.Amount,
                    paid.CreatedBy,
                    paid.Status,
                    paid.PaymentDate,
                    paid.IdTransaction,
                    paid.IsAutoReconcile,
                    paid.IsPartialPayment);
                return paid;
            }, "AddInstallmentPaid", cancellationToken);
        }

        public async Task<Models.Installment> AddNewRecordAsync(Models.Installment installment, CancellationToken cancellationToken = default)
        {
            ValidateEntity(installment, nameof(installment));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Installment,
                    cancellationToken,
                    installment.IdInstallment!,
                    installment.IdBudgetHeader!,
                    installment.UnitName,
                    installment.OwnerName,
                    installment.CreationDate,
                    installment.Amount,
                    installment.Percent,
                    installment.TotalArea,
                    installment.CreatedBy,
                    installment.Status,
                    installment.IdGroupUnit,
                    installment.DueDate,
                    installment.Number,
                    installment.Type,
                    installment.Concept,
                    installment.SourceInstallmentId);
                return installment;
            }, "AddInstallment", cancellationToken);
        }

        public async Task<Models.ViewExpense> AddNewRecordAsync(Models.ViewExpense viewexpense, CancellationToken cancellationToken = default)
        {
            ValidateEntity(viewexpense, nameof(viewexpense));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Expense,
                    cancellationToken,
                    viewexpense.IdExpense!,
                    viewexpense.Description!,
                    viewexpense.Amount!,
                    viewexpense.IncludeInQuota!,
                    viewexpense.ExpenseDate!,
                    viewexpense.Distribution!,
                    viewexpense.Supplier!,
                    viewexpense.IdBuilding!,
                    viewexpense.ReconciledTransactionId!,
                    viewexpense.IdCategory!,
                    viewexpense.Notes!,
                    viewexpense.Status!,
                    viewexpense.PaymentMethod!);
                return viewexpense;
            }, "AddViewExpense", cancellationToken);
        }

        public async Task<Models.OwnerGroupOwner> AddNewRecordAsync(Models.OwnerGroupOwner ownergroupowner, CancellationToken cancellationToken = default)
        {
            ValidateEntity(ownergroupowner, nameof(ownergroupowner));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_OwnerGroupOwner,
                    cancellationToken,
                    ownergroupowner.IdGroupOwner!,
                    ownergroupowner.IdOwner!,
                    ownergroupowner.TypeOwner!);
                return ownergroupowner;
            }, "AddOwnerUnit", cancellationToken);
        }

        public async Task<Models.OwnerUnit> AddNewRecordAsync(Models.OwnerUnit ownerunit, CancellationToken cancellationToken = default)
        {
            ValidateEntity(ownerunit, nameof(ownerunit));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_GroupOwner,
                    cancellationToken,
                    ownerunit.IdGroupOwner!,
                    ownerunit.IdOwner!,
                    ownerunit.GroupName!,
                    ownerunit.AreaTotal!,
                    ownerunit.TypeOwner!,
                    ownerunit.GroupNumber);
                return ownerunit;
            }, "AddOwnerUnit", cancellationToken);
        }

        public async Task<Models.GroupUnit> AddNewRecordAsync(Models.GroupUnit groupunit, CancellationToken cancellationToken = default)
        {
            ValidateEntity(groupunit, nameof(groupunit));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_GroupUnitOwner,
                    cancellationToken,
                    groupunit.IdUnit!,
                    groupunit.IdGroupOwner!,
                    groupunit.TypeGroupUnit!);
                return groupunit;
            }, "AddGroupUnit", cancellationToken);
        }

        public async Task<Models.Parameter> AddNewRecordAsync(Models.Parameter parameter, CancellationToken cancellationToken = default)
        {
            ValidateEntity(parameter, nameof(parameter));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                // INS_Parameter real (confirmado contra el CREATE PROCEDURE):
                //   INS_Parameter(@Description, @ShortDescription, @Value, @Sort,
                //                 @IdParent = NULL, @Estado BIT = 1, @IdBuilding)
                // No toma @IdTabla (IDENTITY, se autogenera). @Estado es BIT --
                // mandar el int crudo del enum (Inactivo=2) se redondea a 1 (Activo).
                //
                // Sistema/Mixto (Paso 3): IdBuilding == Guid.Empty es la convención
                // de la app para "valor de Sistema" (GET_AllParameters coalesa el NULL
                // real de la BD a Guid.Empty al leer -- ver Classes/Parameter.cs). Acá,
                // al escribir, se traduce de vuelta a DBNull -- un DBNull.Value sin
                // tipo en el array de ExecuteStoredProcedureAsync hace que EF tire "no
                // store type mapping for properties of type 'DBNull'" (mismo problema
                // que ya vimos con Parameter.IdParent en UPD_Parameter), así que se
                // arma la llamada a mano con SqlParameter explícitos en vez de usar ese
                // helper.
                var idBuildingParam = new SqlParameter("@IdBuilding", SqlDbType.UniqueIdentifier)
                {
                    Value = parameter.IdBuilding == Guid.Empty ? (object)DBNull.Value : parameter.IdBuilding
                };

                var dbContext = await RentContextAsync(cancellationToken);
                try
                {
                    await dbContext.Database.ExecuteSqlRawAsync(
                        "EXEC dbo.INS_Parameter @Description, @ShortDescription, @Value, @Sort, @IdParent, @Estado, @IdBuilding",
                        new object[]
                        {
                            new SqlParameter("@Description", SqlDbType.NVarChar, 255) { Value = parameter.Description! },
                            new SqlParameter("@ShortDescription", SqlDbType.NVarChar, 100) { Value = parameter.ShortDescription! },
                            new SqlParameter("@Value", SqlDbType.Int) { Value = parameter.Value },
                            new SqlParameter("@Sort", SqlDbType.Int) { Value = parameter.Sort },
                            new SqlParameter("@IdParent", SqlDbType.Int) { Value = parameter.IdParent == 0 ? (object)DBNull.Value : parameter.IdParent },
                            new SqlParameter("@Estado", SqlDbType.Bit) { Value = parameter.Estado == Models.ParameterEstado.Activo },
                            idBuildingParam,
                        },
                        cancellationToken);
                }
                finally
                {
                    ReturnContext(dbContext);
                }

                return parameter;
            }, "AddParameter", cancellationToken);
        }

        public async Task<Building> AddNewRecordAsync(Building building, CancellationToken cancellationToken = default)
        {
            ValidateEntity(building, nameof(building));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                // Number es IDENTITY (autogenerada por SQL Server) -- no se manda, ver
                // Database/Scripts/2026-09-02_18_Fix_Building_NumberIsIdentity.sql.
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Building,
                    cancellationToken,
                    building.IdBuilding,
                    building.Name,
                    building.Location,
                    building.Type,
                    building.Floors,
                    building.Basements,
                    building.Apartments,
                    building.Parkings,
                    building.Deposits,
                    building.Others,
                    building.TotalArea,
                    building.IsActive,
                    building.IsTemplate,
                    (object?)building.IdAccount);
                return building;
            }, "AddBuilding", cancellationToken);
        }

        public async Task<BuildingConfiguration> AddNewRecordAsync(BuildingConfiguration configuration, CancellationToken cancellationToken = default)
        {
            ValidateEntity(configuration, nameof(configuration));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_BuildingConfiguration,
                    cancellationToken,
                    configuration.IdBuildingConfiguration!,
                    configuration.Currency!,
                    // PaymentMethods es List<string> -- EF lo mapea como columna JSON
                    // (primitive collections), pero acá se arma el parámetro a mano con
                    // SqlParameter, que no sabe traducir un List<string> a un tipo ADO.NET
                    // ("No mapping exists from object type
                    // System.Collections.Generic.List`1..."). Se serializa a JSON explícito
                    // para que quede en el mismo formato que la columna espera al leerla de
                    // vuelta (GET_AllBuildingsConfig/GET_BuildingConfiguration).
                    JsonSerializer.Serialize(configuration.PaymentMethods),
                    configuration.PaymentPeriod!,
                    configuration.DueDay!,
                    configuration.FineAmount!,
                    configuration.LateInterestRate!,
                    configuration.InvoiceDay!,
                    configuration.MinWaterConsumtion!,
                    configuration.DefaultFixedCharge!,
                    configuration.IdBuilding!);
                return configuration;
            }, "AddBuildingConfiguration", cancellationToken);
        }

        public async Task<TransactionBankHeader> AddNewRecordAsync(TransactionBankHeader movementheader, CancellationToken cancellationToken = default)
        {
            ValidateEntity(movementheader, nameof(movementheader));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_MovementHeader,
                    cancellationToken,
                    movementheader.IdStatementHeader!,
                    movementheader.FileName!,
                    movementheader.IdUser!,
                    movementheader.TotalRecords!,
                    movementheader.UploadState!,
                    movementheader.IdBankAccount!);
                return movementheader;
            }, "AddMovementHeader", cancellationToken);
        }

        public async Task<TransactionBankDetail> AddNewRecordAsync(TransactionBankDetail movementdetail, CancellationToken cancellationToken = default)
        {
            ValidateEntity(movementdetail, nameof(movementdetail));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_AccountStatementDetail,
                    cancellationToken,
                    movementdetail.IdStatementDetail,
                    movementdetail.IdStatementHeader,
                    movementdetail.StatementDate,
                    movementdetail.Description,
                    movementdetail.ITF,
                    movementdetail.Currency,
                    movementdetail.Amount,
                    movementdetail.SequenceNumber,
                    // INS_AccountStatementDetail.@ReconciliationStatus es BIT -- pasar el
                    // enum ConcilationType directo (un objeto boxeado de un tipo que
                    // ADO.NET no reconoce) hacía que SIEMPRE se guardara 1/Conciliada, sin
                    // importar el valor real (confirmado: 27 filas recién insertadas con
                    // ReconciliationStatus = 0/NoConciliada en C# terminaron las 27 en BD
                    // como 1). Convertir explícito a bool antes de mandarlo evita que
                    // ADO.NET tenga que adivinar el tipo del parámetro para un enum.
                    (int)movementdetail.ReconciliationStatus != 0,
                    movementdetail.ReconciliationDate!,
                    movementdetail.IdParent,
                    movementdetail.Origen);
                return movementdetail;
            }, "AddMovementDetail", cancellationToken);
        }

        public async Task<Expense> AddNewRecordAsync(Expense expense, CancellationToken cancellationToken = default)
        {
            ValidateEntity(expense, nameof(expense));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Expense,
                    cancellationToken,
                    expense.ExpenseDescription!,
                    expense.TotalAmount!,
                    expense.IsIncludedInQuota!,
                    expense.DueDate!,
                    expense.IdDistribution!,
                    expense.IdBuilding!,
                    expense.IdSubCategory!);
                return expense;
            }, "AddExpense", cancellationToken);
        }

        public async Task<BankAccount> AddNewRecordAsync(BankAccount bankaccount, CancellationToken cancellationToken = default)
        {
            ValidateEntity(bankaccount, nameof(bankaccount));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_BankAccount,
                    cancellationToken,
                    bankaccount.IdBankAccount!,
                    bankaccount.AccountName!,
                    bankaccount.AccountNumber!,
                    bankaccount.BankName!,
                    bankaccount.AccountType!,
                    bankaccount.IdBuilding!,
                    bankaccount.Status!,
                    bankaccount.CCI!,
                    bankaccount.InitialBalance);
                return bankaccount;
            }, "AddBankAccount", cancellationToken);
        }

        public async Task<Exoneration> AddNewRecordAsync(Exoneration exoneration, CancellationToken cancellationToken = default)
        {
            ValidateEntity(exoneration, nameof(exoneration));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Exoneration,
                    cancellationToken,
                    exoneration.IdExoneration,
                    exoneration.IdGroupUnit,
                    exoneration.IdCategory,
                    exoneration.Description,
                    exoneration.IsActive,
                    exoneration.CreatedBy,
                    exoneration.UpdatedBy,
                    exoneration.IdBuilding);
                return exoneration;
            }, "AddExoneration", cancellationToken);
        }

        public async Task<Period> AddNewRecordAsync(Period period, CancellationToken cancellationToken = default)
        {
            ValidateEntity(period, nameof(period));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Periods,
                    cancellationToken,
                    period.IdPeriod,
                    period.Name,
                    period.PeriodType,
                    period.StartDate,
                    period.EndDate,
                    period.ClosingDate,
                    period.Status,
                    period.IsCurrentPeriod,
                    period.Description,
                    period.IdBuilding);
                return period;
            }, "AddPeriod", cancellationToken);
        }

        public async Task<ServiceReading> AddNewRecordAsync(ServiceReading serviceReading, CancellationToken cancellationToken = default)
        {
            ValidateEntity(serviceReading, nameof(serviceReading));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_ServiceReading,
                    cancellationToken,
                    serviceReading.IdServiceReading,
                    serviceReading.Period,
                    serviceReading.Status,
                    serviceReading.IdBuilding,
                    serviceReading.FileName,
                    serviceReading.TotalAmount,
                    serviceReading.IdPeriod);
                return serviceReading;
            }, "AddServiceReading", cancellationToken);
        }

        public async Task AddNewRecordAsync(List<ServiceReadingDetail> serviceReadingDetails, CancellationToken cancellationToken = default)
        {
            ValidateEntity(serviceReadingDetails, nameof(serviceReadingDetails));

            await ExecuteWithErrorHandlingAsync(async () =>
            {
                //using var transaction = await _dbContext.Database.BeginTransactionAsync(cancellationToken);

                try
                {
                    foreach (var detail in serviceReadingDetails)
                    {
                        ValidateEntity(detail, nameof(detail));

                        await ExecuteStoredProcedureAsync(
                            StoredProcedures.INS_ServiceReadingDetail,
                            cancellationToken,
                            detail.IdServiceReadingDetail,
                            detail.IdGroupUnit,
                            Math.Round(Convert.ToDecimal(detail.CurrentReading), 4),
                            Math.Round(Convert.ToDecimal(detail.Consumption), 4),
                            detail.ReadingDate,
                            detail.Code,
                            detail.CalculatedAmount,
                            detail.Minimum,
                            detail.IdServiceReading);
                    }
                    // await transaction.CommitAsync(cancellationToken);
                }
                catch (Exception ex)
                {
                    //await transaction.RollbackAsync(cancellationToken);
                    throw new Exception(ex.Message);
                }

                return true;
            }, "AddServiceReadingDetails", cancellationToken);
        }

        public async Task<Contact> AddNewRecordAsync(Contact contact, CancellationToken cancellationToken = default)
        {
            ValidateEntity(contact, nameof(contact));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Contact,
                    cancellationToken,
                    contact.IdContact,
                    contact.TypeContact,
                    contact.Name,
                    contact.Phone,
                    contact.Email,
                    contact.Address,
                    contact.OfficePhone,
                    contact.MobilePhone,
                    contact.IdRelatedEntity);
                return contact;
            }, "AddContact", cancellationToken);
        }

        public async Task<Category> AddNewRecordAsync(Models.Category category, CancellationToken cancellationToken = default)
        {
            ValidateEntity(category, nameof(category));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Category,
                    cancellationToken,
                    category.IdCategory,
                    category.Description,
                    category.ShortDescript,
                    category.Icon,
                    category.Color,
                    category.Distribution,
                    category.ParentId! == Guid.Empty ? null! : category.ParentId!,
                    category.IdBuilding,
                    category.Sort,
                    category.ShowDetailInReceipt);
                return category;
            }, "AddCategory", cancellationToken);
        }

        public async Task<Owner> AddNewRecordAsync(Owner owner, CancellationToken cancellationToken = default)
        {
            ValidateEntity(owner, nameof(owner));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                var newId = Guid.NewGuid();
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Owner,
                    cancellationToken,
                    newId,
                    owner.IdNumber,
                    owner.Names,
                    owner.Surname!,
                    owner.Address,
                    owner.PhoneNumber,
                    owner.IdBuilding,
                    owner.IdTypeIdNumber,
                    (object?)owner.Email,
                    owner.IsActive,
                    (object?)owner.MobilePhone,
                    (object?)owner.WorkPhone,
                    (object?)owner.RelationshipType,
                    (object?)owner.BusinessName,
                    (object?)owner.LegalRepresentative,
                    (object?)owner.RucType,
                    (object?)owner.Nationality,
                    (object?)owner.CivilStatus,
                    (object?)owner.BirthDate);
                owner.IdOwner = newId;
                return owner;
            }, "AddOwner", cancellationToken);
        }

        public async Task<RealEstateUnit> AddNewRecordAsync(RealEstateUnit unit, CancellationToken cancellationToken = default)
        {
            ValidateEntity(unit, nameof(unit));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                var newId = Guid.NewGuid();
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Unit,
                    cancellationToken,
                    newId,
                    unit.UnitNumber,
                    unit.Area,
                    unit.Number,
                    unit.TypeUnit,
                    unit.IsAvailable,
                    unit.IdBuilding,
                    (object?)unit.Floor,
                    (object?)unit.Tower,
                    (object?)unit.LocationCode,
                    (object?)unit.Bedrooms,
                    (object?)unit.Bathrooms,
                    (object?)unit.BuiltArea,
                    (object?)unit.IsCovered,
                    (object?)unit.IsForDisabled,
                    (object?)unit.VehicleType,
                    (object?)unit.Height,
                    (object?)unit.HasVentilation,
                    (object?)unit.HasElectricity,
                    (object?)unit.Notes);
                unit.IdUnit = newId;
                return unit;
            }, "AddUnit", cancellationToken);
        }

        public async Task<BudgetHeader> AddNewRecordAsync(BudgetHeader budgetHeader, CancellationToken cancellationToken = default)
        {
            ValidateEntity(budgetHeader, nameof(budgetHeader));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_BudgetHeader,
                    cancellationToken,
                    budgetHeader.IdBudgetHeader,
                    budgetHeader.BudgetName,
                    budgetHeader.BudgetDate,
                    budgetHeader.Amount,
                    budgetHeader.AnnualAmount,
                    budgetHeader.BudgetType,
                    budgetHeader.IdBuilding,
                    budgetHeader.Status,
                    budgetHeader.CreatedBy,
                    budgetHeader.IdPeriod);
                return budgetHeader;
            }, "AddBudgetHeader", cancellationToken);
        }

        public async Task<BudgetDetail> AddNewRecordAsync(BudgetDetail budgetDetail, CancellationToken cancellationToken = default)
        {
            ValidateEntity(budgetDetail, nameof(budgetDetail));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_BudgetDetail,
                    cancellationToken,
                    budgetDetail.IdBudgetDetail,
                    budgetDetail.IdCategory,
                    budgetDetail.IdSection,
                    budgetDetail.ItemNumber,
                    budgetDetail.Description,
                    budgetDetail.MonthlyAmount,
                    budgetDetail.AnnualAmount,
                    budgetDetail.Frequency,
                    budgetDetail.Type,
                    budgetDetail.IsHeader,
                    budgetDetail.IdBudgetHeader);
                return budgetDetail;
            }, "AddBudgetDetail", cancellationToken);
        }

        public async Task<Models.Workflow> AddNewRecordAsync(Models.Workflow workflow, CancellationToken cancellationToken = default)
        {
            ValidateEntity(workflow, nameof(workflow));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Workflow,
                    cancellationToken,
                    workflow.IdWorkflow,
                    workflow.Name,
                    workflow.Description,
                    (int)workflow.Status);
                return workflow;
            }, "AddWorkflow", cancellationToken);
        }

        public async Task<Models.WorkflowAuditEntry> AddNewRecordAsync(Models.WorkflowAuditEntry entry, CancellationToken cancellationToken = default)
        {
            ValidateEntity(entry, nameof(entry));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_WorkflowAuditLog,
                    cancellationToken,
                    entry.Id,
                    entry.Module,
                    entry.EntityId,
                    entry.Action.ToString(),
                    entry.PerformedBy,
                    (object?)entry.Comment,
                    entry.IdBuilding);
                return entry;
            }, "AddWorkflowAuditLog", cancellationToken);
        }

        // Pantalla de administración de Permisos (sólo SysAdmin) -- antes esto sólo se podía
        // hacer con un INSERT manual (ver Database/Scripts/2026-09-09_76_Seed_ReportPermissions.sql).
        public async Task<Models.PermissionDefinition> AddNewRecordAsync(Models.PermissionDefinition permiso, CancellationToken cancellationToken = default)
        {
            ValidateEntity(permiso, nameof(permiso));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Permission,
                    cancellationToken,
                    permiso.PermissionId,
                    permiso.PermissionKey,
                    permiso.Name,
                    (object?)permiso.Description,
                    permiso.Group);
                return permiso;
            }, "AddPermission", cancellationToken);
        }

        // Docs/Pendientes-Negocio-Conciliacion.md #5
        public async Task<Models.ExpenseTemplate> AddNewRecordAsync(Models.ExpenseTemplate plantilla, CancellationToken cancellationToken = default)
        {
            ValidateEntity(plantilla, nameof(plantilla));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_ExpenseTemplate,
                    cancellationToken,
                    plantilla.IdExpenseTemplate,
                    plantilla.IdBuilding,
                    plantilla.DescriptionPattern,
                    plantilla.IdCategory,
                    (int)plantilla.Distribution,
                    (object?)plantilla.Supplier,
                    plantilla.CreatedBy);
                return plantilla;
            }, "AddExpenseTemplate", cancellationToken);
        }

        // Docs/Pendientes-Negocio-Consolidado.md #18b -- inserta el registro de un
        // recibo PDF ya generado y guardado en storage. IX_ReceiptFile_Installment
        // (UNIQUE) rechaza un segundo INSERT para la misma cuota -- el caller
        // (IReceiptStorageService) decide qué hacer si eso pasa (doble click / dos
        // pestañas generando el mismo recibo a la vez).
        public async Task<Models.ReceiptFile> AddNewRecordAsync(Models.ReceiptFile receiptFile, CancellationToken cancellationToken = default)
        {
            ValidateEntity(receiptFile, nameof(receiptFile));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_ReceiptFile,
                    cancellationToken,
                    receiptFile.IdReceiptFile,
                    receiptFile.IdInstallment,
                    receiptFile.IdBuilding,
                    receiptFile.FilePath,
                    receiptFile.FileSizeBytes,
                    receiptFile.GeneratedBy);
                return receiptFile;
            }, "AddReceiptFile", cancellationToken);
        }

        // Docs/Pendientes-Negocio-Conciliacion.md #3
        public async Task<Models.Conciliacion> AddNewRecordAsync(Models.Conciliacion sesion, CancellationToken cancellationToken = default)
        {
            ValidateEntity(sesion, nameof(sesion));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_ReconciliationSession,
                    cancellationToken,
                    sesion.Id,
                    sesion.CuentaBancariaId,
                    sesion.IdBuilding,
                    sesion.FechaInicio,
                    sesion.FechaFin,
                    sesion.TransaccionesProcesadas,
                    sesion.TransaccionesConciliadas,
                    sesion.Diferencia,
                    sesion.Completada,
                    sesion.Fecha,
                    sesion.Usuario,
                    (object?)(string.IsNullOrWhiteSpace(sesion.Notas) ? null : sesion.Notas));
                return sesion;
            }, "AddReconciliationSession", cancellationToken);
        }

        public async Task<Models.SystemLogEntry> AddNewRecordAsync(Models.SystemLogEntry entry, CancellationToken cancellationToken = default)
        {
            ValidateEntity(entry, nameof(entry));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_SystemLog,
                    cancellationToken,
                    entry.Id,
                    entry.Timestamp,
                    entry.Level,
                    entry.Category,
                    entry.Message,
                    (object?)entry.Exception,
                    (object?)entry.IdUser,
                    (object?)entry.UserName,
                    (object?)entry.IdBuilding);
                return entry;
            }, "AddSystemLog", cancellationToken);
        }

        public async Task<Models.Incident> AddNewRecordAsync(Models.Incident incident, CancellationToken cancellationToken = default)
        {
            ValidateEntity(incident, nameof(incident));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Incident,
                    cancellationToken,
                    incident.IdIncident,
                    incident.IdBuilding,
                    incident.Title,
                    incident.Description,
                    incident.Type,
                    incident.Priority,
                    incident.Status.ToString(),
                    (object?)incident.IdGroupUnit,
                    incident.ReportedBy,
                    incident.CreatedBy);
                return incident;
            }, "AddIncident", cancellationToken);
        }

        public async Task<Models.IncidentComment> AddNewRecordAsync(Models.IncidentComment comment, CancellationToken cancellationToken = default)
        {
            ValidateEntity(comment, nameof(comment));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_IncidentComment,
                    cancellationToken,
                    comment.IdComment,
                    comment.IdIncident,
                    comment.AuthorId,
                    comment.Text,
                    comment.IsInternal);
                return comment;
            }, "AddIncidentComment", cancellationToken);
        }

        public async Task<Models.IncidentAttachment> AddNewRecordAsync(Models.IncidentAttachment attachment, CancellationToken cancellationToken = default)
        {
            ValidateEntity(attachment, nameof(attachment));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_IncidentAttachment,
                    cancellationToken,
                    attachment.IdAttachment,
                    attachment.IdIncident,
                    attachment.IdBuilding,
                    attachment.FileName,
                    attachment.ContentType,
                    attachment.FileSizeBytes,
                    attachment.FilePath,
                    attachment.UploadedBy);
                return attachment;
            }, "AddIncidentAttachment", cancellationToken);
        }

        public async Task<Models.Comunicado> AddNewRecordAsync(Models.Comunicado comunicado, CancellationToken cancellationToken = default)
        {
            ValidateEntity(comunicado, nameof(comunicado));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Comunicado,
                    cancellationToken,
                    comunicado.IdComunicado,
                    comunicado.IdBuilding,
                    comunicado.Titulo,
                    comunicado.Cuerpo,
                    comunicado.IdCategoria,
                    (int)comunicado.Alcance,
                    (object?)comunicado.RolReservado ?? DBNull.Value,
                    comunicado.EnviarPorCorreo,
                    comunicado.CreatedBy);
                return comunicado;
            }, "AddComunicado", cancellationToken);
        }

        public async Task<Models.ComunicadoDestinatario> AddNewRecordAsync(Models.ComunicadoDestinatario destinatario, CancellationToken cancellationToken = default)
        {
            ValidateEntity(destinatario, nameof(destinatario));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_ComunicadoDestinatario,
                    cancellationToken,
                    destinatario.IdComunicadoDestinatario,
                    destinatario.IdComunicado,
                    (object?)destinatario.IdGroupUnit ?? DBNull.Value,
                    destinatario.NombreDestinatario,
                    (object?)destinatario.Telefono ?? DBNull.Value,
                    (object?)destinatario.Email ?? DBNull.Value,
                    (int)destinatario.EstadoWhatsApp,
                    (int)destinatario.EstadoCorreo);
                return destinatario;
            }, "AddComunicadoDestinatario", cancellationToken);
        }

        public async Task<Models.AreaComun> AddNewRecordAsync(Models.AreaComun areaComun, CancellationToken cancellationToken = default)
        {
            ValidateEntity(areaComun, nameof(areaComun));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_AreaComun,
                    cancellationToken,
                    areaComun.IdAreaComun,
                    areaComun.IdBuilding,
                    areaComun.Nombre,
                    (object?)areaComun.Descripcion ?? DBNull.Value,
                    (object?)areaComun.AforoMaximo ?? DBNull.Value,
                    (object?)areaComun.DuracionMinMinutos ?? DBNull.Value,
                    (object?)areaComun.DuracionMaxMinutos ?? DBNull.Value,
                    areaComun.BufferMinutos,
                    areaComun.AnticipacionMinHoras,
                    (object?)areaComun.AnticipacionMaxDias ?? DBNull.Value,
                    (object?)areaComun.TopeReservasActivasPorUnidad ?? DBNull.Value,
                    areaComun.GarantiaInternos,
                    areaComun.GarantiaExternos,
                    areaComun.AlquilerInternos,
                    areaComun.AlquilerExternos,
                    areaComun.Limpieza,
                    areaComun.PenalidadCancelacionHabilitada,
                    (object?)areaComun.DiasMinimosSinPenalidad ?? DBNull.Value,
                    areaComun.PenalidadNoPresentadoHabilitada,
                    areaComun.CreatedBy);
                return areaComun;
            }, "AddAreaComun", cancellationToken);
        }

        public async Task<Models.Reserva> AddNewRecordAsync(Models.Reserva reserva, CancellationToken cancellationToken = default)
        {
            ValidateEntity(reserva, nameof(reserva));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Reserva,
                    cancellationToken,
                    reserva.IdReserva,
                    reserva.IdBuilding,
                    reserva.IdAreaComun,
                    reserva.IdGroupUnit,
                    reserva.FechaInicio,
                    reserva.FechaFin,
                    reserva.EsExterno,
                    (object?)reserva.OrganizadorNombre ?? DBNull.Value,
                    (object?)reserva.OrganizadorDocumento ?? DBNull.Value,
                    (object?)reserva.OrganizadorTelefono ?? DBNull.Value,
                    (int)reserva.Estado,
                    reserva.MontoGarantia,
                    reserva.MontoAlquiler,
                    reserva.MontoLimpieza,
                    (object?)reserva.IdCalendarItem ?? DBNull.Value,
                    reserva.CreatedBy);
                return reserva;
            }, "AddReserva", cancellationToken);
        }

        public async Task<Models.ReservaChecklistItem> AddNewRecordAsync(Models.ReservaChecklistItem item, CancellationToken cancellationToken = default)
        {
            ValidateEntity(item, nameof(item));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_ReservaChecklistItem,
                    cancellationToken,
                    item.IdChecklistItem,
                    item.IdReserva,
                    (int)item.Etapa,
                    item.Descripcion,
                    (int)item.Estado,
                    (object?)item.Observacion ?? DBNull.Value,
                    item.CreatedBy);
                return item;
            }, "AddReservaChecklistItem", cancellationToken);
        }

        public async Task<Models.ReservaAttachment> AddNewRecordAsync(Models.ReservaAttachment attachment, CancellationToken cancellationToken = default)
        {
            ValidateEntity(attachment, nameof(attachment));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_ReservaAttachment,
                    cancellationToken,
                    attachment.IdAttachment,
                    attachment.IdReserva,
                    (int)attachment.Etapa,
                    attachment.FileName,
                    attachment.ContentType,
                    attachment.FileSizeBytes,
                    attachment.FilePath,
                    attachment.UploadedBy);
                return attachment;
            }, "AddReservaAttachment", cancellationToken);
        }

        public async Task<Models.IngresoComunidad> AddNewRecordAsync(Models.IngresoComunidad ingreso, CancellationToken cancellationToken = default)
        {
            ValidateEntity(ingreso, nameof(ingreso));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_IngresoComunidad,
                    cancellationToken,
                    ingreso.IdIngreso,
                    ingreso.IdBuilding,
                    ingreso.Concepto,
                    ingreso.Monto,
                    (object?)ingreso.IdReserva ?? DBNull.Value,
                    ingreso.CreatedBy);
                return ingreso;
            }, "AddIngresoComunidad", cancellationToken);
        }

        public async Task<Models.CalendarItem> AddNewRecordAsync(Models.CalendarItem item, CancellationToken cancellationToken = default)
        {
            ValidateEntity(item, nameof(item));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_CalendarItem,
                    cancellationToken,
                    item.IdCalendarItem,
                    item.IdBuilding,
                    item.Title,
                    item.Description,
                    item.Type.ToString(),
                    (object?)item.IdCategory,
                    item.StartDate,
                    (object?)item.EndDate,
                    item.Location,
                    item.Responsible,
                    (object?)item.Cost,
                    item.Status.ToString(),
                    item.Recurrence.ToString(),
                    item.RecurrenceInterval,
                    (object?)item.RecurrenceEndDate,
                    (object?)item.IdRecurrenceGroup,
                    item.IsRecurrenceMaster,
                    item.CreatedBy);
                return item;
            }, "AddCalendarItem", cancellationToken);
        }

        public async Task<Models.WorkflowStep> AddNewRecordAsync(Models.WorkflowStep step, CancellationToken cancellationToken = default)
        {
            ValidateEntity(step, nameof(step));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_WorkflowStep,
                    cancellationToken,
                    step.IdWorkflowStep,
                    step.IdWorkflow,
                    step.StepOrder,
                    step.Name,
                    step.Description,
                    step.Responsible,
                    step.IsImplemented);
                return step;
            }, "AddWorkflowStep", cancellationToken);
        }

        public async Task<Models.Subscription> AddNewRecordAsync(Models.Subscription subscription, CancellationToken cancellationToken = default)
        {
            ValidateEntity(subscription, nameof(subscription));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Subscription,
                    cancellationToken,
                    subscription.IdSubscription,
                    subscription.IdUser,
                    (object?)subscription.IdAccount,
                    subscription.IdSubscriptionPlan,
                    subscription.Status,
                    subscription.StartDate,
                    (object?)subscription.EndDate);
                return subscription;
            }, "AddSubscription", cancellationToken);
        }

        public async Task<Models.Account> AddNewRecordAsync(Models.Account account, CancellationToken cancellationToken = default)
        {
            ValidateEntity(account, nameof(account));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_Account,
                    cancellationToken,
                    account.IdAccount,
                    (object?)account.RazonSocial,
                    (object?)account.RucDni,
                    (object?)account.Telefono);
                return account;
            }, "AddAccount", cancellationToken);
        }

        // A diferencia de los demás AddNewRecordAsync, no toma una entidad completa --
        // AccountUser siempre nace de una acción puntual (crear cuenta -> Owner,
        // aceptar invitación -> Colaborador), nunca de un formulario con todos sus
        // campos.
        public async Task AddAccountUserAsync(Guid idAccount, Guid idUser, string role, CancellationToken cancellationToken = default)
        {
            await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_AccountUser,
                    cancellationToken,
                    Guid.NewGuid(),
                    idAccount,
                    idUser,
                    role);
                return true;
            }, "AddAccountUser", cancellationToken);
        }

        public async Task<Models.AccountInvitation> AddNewRecordAsync(Models.AccountInvitation invitation, CancellationToken cancellationToken = default)
        {
            ValidateEntity(invitation, nameof(invitation));

            return await ExecuteWithErrorHandlingAsync(async () =>
            {
                await ExecuteStoredProcedureAsync(
                    StoredProcedures.INS_AccountInvitation,
                    cancellationToken,
                    invitation.IdAccountInvitation,
                    invitation.IdAccount,
                    invitation.Email,
                    invitation.Code,
                    invitation.InvitedByIdUser);
                return invitation;
            }, "AddAccountInvitation", cancellationToken);
        }
        #endregion
    }
}