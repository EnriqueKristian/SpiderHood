﻿using DocumentFormat.OpenXml.InkML;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SpiderHood.Data;
using SpiderHood.Models;

namespace SpiderHood.Services
{
    public interface IExpenseService
    {
        Task<List<ViewExpense>> ObtenerGastosPendientesConciliacionAsync(Guid IdBuilding, DateTime desde, DateTime hasta);
        //Task<List<CategoriaGasto>> ObtenerCategoriasAsync();
        Task<ViewExpense> CrearGastoAsync(ViewExpense gasto);
        Task MarcarGastoComoConciliadoAsync(Guid gastoId, Guid transaccionId);
        Task DesconciliarGastoAsync(Guid gastoId);
        Task AddExpenseAsync(ViewExpense expense);
        Task AddExpenseAsync(Expense expense);
        Task UpdateExpenseAsync(Expense expense);
        Task UpdateExpenseAsync(ViewExpense expense);
        // OJO: devuelve ViewExpense, no Expense -- ver el comentario grande en
        // GetExpensesByBuildingAsync (implementación) para el porqué.
        Task<List<ViewExpense>> GetExpensesByBuildingAsync(Guid IdBuilding);
        Task<OperationResult> DeleteExpenseAsync(ViewExpense expense);
    }

    public class ExpenseService : IExpenseService
    {
        private List<ViewExpense> gastos = new();
        //private List<CategoriaGasto> categorias = new();
        public BDLayout ec = default!;
        private readonly AuthService _authService;

        public ExpenseService(IDbContextFactory<SpiderHoodContext> contextFactory, AuthService authService)
        {
            ec = new BDLayout(contextFactory);
            _authService = authService ?? throw new ArgumentNullException(nameof(authService));
            InicializarDatos();
        }

        private async Task<string> GetPerformedByAsync()
        {
            var user = await _authService.GetCurrentUserAsync();
            return user?.Email ?? "system";
        }

        private void InicializarDatos()
        {
            // Inicializar categorías
            /*categorias = new List<CategoriaGasto>
            {
                new CategoriaGasto { Id = 1, Nombre = "Servicios", Descripcion = "Agua, luz, gas, internet" },
                new CategoriaGasto { Id = 2, Nombre = "Mantenimiento", Descripcion = "Reparaciones y mejoras" },
                new CategoriaGasto { Id = 3, Nombre = "Limpieza", Descripcion = "Limpieza de áreas comunes" },
                new CategoriaGasto { Id = 4, Nombre = "Seguridad", Descripcion = "Vigilancia y sistemas de seguridad" },
                new CategoriaGasto { Id = 5, Nombre = "Personal", Descripcion = "Sueldos y honorarios" },
                new CategoriaGasto { Id = 6, Nombre = "Suministros", Descripcion = "Materiales y provisiones" },
                new CategoriaGasto { Id = 7, Nombre = "Seguros", Descripcion = "Pólizas de seguro" },
                new CategoriaGasto { Id = 8, Nombre = "Impuestos", Descripcion = "Impuestos y contribuciones" },
                new CategoriaGasto { Id = 9, Nombre = "Varios", Descripcion = "Otros gastos no categorizados" }
            };*/

            // Inicializar gastos de ejemplo
            gastos = new List<ViewExpense>
            {
                new ViewExpense
                {
                    IdExpense = new Guid(),
                    Description = "Pago Agua",
                    Amount = 1154.70m,
                    ExpenseDate = DateTime.Now.AddDays(-15),
                    Category = "Servicios",
                    Supplier = "CFE",
                    Status = StatusExpense.Approved,
                    Reconciled  = false,
                    ReconciledTransactionId  =new Guid()
                },
                new ViewExpense
                {
                    IdExpense = new Guid(),
                    Description = "Pago Luz",
                    Amount = 1150.20m,
                    ExpenseDate = DateTime.Now.AddDays(-15),
                    Category = "Servicios",
                    Supplier = "CFE",
                    Status =StatusExpense.Approved,
                    Reconciled = false,
                    ReconciledTransactionId = new Guid()
                },
                new ViewExpense
                {
                    IdExpense = new Guid(),
                    Description = "Mantenimiento Ascensor",
                    Amount = 8500.00m,
                    ExpenseDate = DateTime.Now.AddDays(-10),
                    Category = "Mantenimiento",
                    Supplier = "Elevadores MX",
                    Status = StatusExpense.Approved,
                    Reconciled = false
                },
                new ViewExpense
                {
                    IdExpense = new Guid(),
                    Description = "Mantenimiento Puerta",
                    Amount = 8500.00m,
                    ExpenseDate = DateTime.Now.AddDays(-10),
                    Category = "Mantenimiento",
                    Supplier = "Don Jorge Cerrajero",
                    Status =StatusExpense.Approved,
                    Reconciled = false
                },
                new ViewExpense
                {
                    IdExpense = new Guid(),
                    Description = "Limpieza Semanal",
                    Amount = 3200.00m,
                    ExpenseDate = DateTime.Now.AddDays(-5),
                    Category = "Limpieza",
                    Supplier = "Limpieza Total",
                    Status = StatusExpense.Approved,
                    Reconciled = false
                }
            };
        }

        public async Task<List<ViewExpense>> ObtenerGastosPendientesConciliacionAsync(Guid IdBuilding, DateTime desde, DateTime hasta)
        {
            return await ec.GetPendingConciliationExpensesAsync(IdBuilding, desde, hasta);
        }


        public async Task AddExpenseAsync(ViewExpense expense)
        {
            await ec.AddNewRecordAsync(expense);
            await ec.StampAuditAsync(AuditableEntity.Expense, expense.IdExpense, await GetPerformedByAsync(), isCreate: true);
        }

        // OJO: roto desde siempre, no tocado a propósito -- AddNewRecordAsync(Expense)
        // (BDLayout.Add.cs) le pasa a INS_Expense sólo 7 parámetros posicionales
        // (ExpenseDescription/TotalAmount/IsIncludedInQuota/DueDate/IdDistribution/
        // IdBuilding/IdSubCategory) contra un SP real de 13 parámetros obligatorios
        // (@IdExpense/@Description/@Amount/@IncludeInQuota/@ExpenseDate/@Distribution/
        // @Supplier/@IdBuilding/@IdStatementDetail/@IdCategory/@Notes/@Status/
        // @PaymentMethod) -- fallaría en cuanto se llamara. Classes/Expense.cs no
        // coincide con ninguna columna real de dbo.Expense (confirmado con
        // INFORMATION_SCHEMA.COLUMNS); la clase correcta es ViewExpense, ver
        // AddExpenseAsync(ViewExpense) arriba y UpdateExpenseAsync(ViewExpense) abajo,
        // que sí se usan desde ExpensePage.razor. No se borra este método por las
        // dudas de que algo más lo referencie por reflection/tests, pero no lo llama
        // nadie confirmado.
        public async Task AddExpenseAsync(Expense expense)
        {
            await ec.AddNewRecordAsync(expense);
            await ec.StampAuditAsync(AuditableEntity.Expense, expense.IdExpense, await GetPerformedByAsync(), isCreate: true);
        }

        // OJO: mismo problema que AddExpenseAsync(Expense) -- UPD_Expense (antes del
        // fix en Database/Scripts/2026-09-10_83_Fix_UPD_Expense_And_Category.sql)
        // referenciaba columnas inexistentes (TotalAmount/IsInstallment/TypeDistribution).
        // Ya corregido en el SP, pero Classes/Expense.cs sigue sin coincidir con el
        // resto del schema real -- no se usa desde ExpensePage.razor, que ahora llama
        // a UpdateExpenseAsync(ViewExpense).
        public async Task UpdateExpenseAsync(Expense expense)
        {
            // Antes llamaba AddNewRecordAsync (INS_Expense) en vez de UpdateRecordAsync
            // (UPD_Expense) -- una actualización terminaba insertando una fila duplicada
            // en vez de modificar la existente.
            await ec.UpdateRecordAsync(expense);
            await ec.StampAuditAsync(AuditableEntity.Expense, expense.IdExpense, await GetPerformedByAsync(), isCreate: false);
        }

        public async Task UpdateExpenseAsync(ViewExpense expense)
        {
            await ec.UpdateRecordAsync(expense);
            await ec.StampAuditAsync(AuditableEntity.Expense, expense.IdExpense, await GetPerformedByAsync(), isCreate: false);
        }

        // OJO: devuelve List<ViewExpense>, no List<Expense> -- GET_ExpensesByBuilding
        // (el SP real) devuelve columnas que coinciden con ViewExpense.cs
        // (Description/Amount/Supplier/PaymentMethod/Status/Notes/AutoReconcile/
        // ExpenseDate/IncludeInQuota/Distribution como int), confirmado con
        // INFORMATION_SCHEMA.COLUMNS de dbo.Expense -- Classes/Expense.cs (que
        // esperaba ExpenseDescription/TotalAmount/SubCategory/DueDate/Provider/etc.)
        // nunca coincidió con ninguna columna real de la tabla. Antes de este cambio,
        // /expense tiraba "Invalid column name" apenas cargaba con datos reales.
        public async Task<List<ViewExpense>> GetExpensesByBuildingAsync(Guid IdBuilding)
        {
            return await ec.GetExpensesByBuildingAsync(IdBuilding);
        }

        // Mismo patrón que CategoryService.DeleteCategoryAsync: DEL_Expense es un DELETE
        // simple (ver Database/Scripts/2026-09-10_81_DEL_Expense.sql) -- si el gasto
        // tiene alguna referencia real desde otra tabla, esto falla con SQL 547 en vez
        // de dejar datos huérfanos, y se traduce a un mensaje legible en vez de la
        // RepositoryException genérica.
        public async Task<OperationResult> DeleteExpenseAsync(ViewExpense expense)
        {
            try
            {
                await ec.DeleteRecordAsync(expense);
                return OperationResult.Success();
            }
            catch (Exception ex)
            {
                if (IsForeignKeyViolation(ex))
                {
                    return OperationResult.Failure(
                        "No se puede eliminar: el gasto está en uso (conciliado con una transacción bancaria u otra referencia).");
                }

                Console.WriteLine($"Error al eliminar el gasto: {ex.Message}");
                return OperationResult.Failure($"No se pudo eliminar el gasto: {DescribeError(ex)}");
            }
        }

        // BDLayout envuelve la excepción real (la de SQL Server) en una
        // RepositoryException genérica -- mismo patrón que CategoryService.DescribeError.
        private static string DescribeError(Exception ex)
        {
            var innermost = ex;
            while (innermost.InnerException != null)
                innermost = innermost.InnerException;
            return innermost.Message;
        }

        private static bool IsForeignKeyViolation(Exception ex)
        {
            var innermost = ex;
            while (innermost.InnerException != null)
                innermost = innermost.InnerException;
            return innermost is SqlException sqlEx && sqlEx.Number == 547;
        }

        public async Task<ViewExpense> CrearGastoAsync(ViewExpense gasto)
        {

            gasto.IdExpense = Guid.NewGuid(); //gastos.Max(g => g.Id) + 1;
            await ec.AddNewRecordAsync(gasto);
            await ec.StampAuditAsync(AuditableEntity.Expense, gasto.IdExpense, await GetPerformedByAsync(), isCreate: true);
            gasto.ExpenseDate = DateTime.Now;
            gastos.Add(gasto);

            return gasto;
        }

        public async Task MarcarGastoComoConciliadoAsync(Guid gastoId, Guid transaccionId)
        {
            var gasto = gastos.FirstOrDefault(g => g.IdExpense == gastoId);
            if (gasto != null)
            {
                gasto.Reconciled = true;
                gasto.ReconciledTransactionId = new Guid(); //transaccionId;
            }
        }

        public async Task DesconciliarGastoAsync(Guid gastoId)
        {
            var gasto = gastos.FirstOrDefault(g => g.IdExpense == gastoId);
            if (gasto != null)
            {
                gasto.Reconciled = false;
                gasto.ReconciledTransactionId = Guid.Empty;
            }
        }
    }
}