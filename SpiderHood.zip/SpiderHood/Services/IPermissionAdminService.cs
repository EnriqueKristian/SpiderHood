﻿// Services/IPermissionAdminService.cs
using Microsoft.EntityFrameworkCore;
using SpiderHood.Data;
using SpiderHood.Models;

namespace SpiderHood.Services
{
    public interface IPermissionAdminService
    {
        Task<List<Role>> GetAllRolesAsync();
        Task<Role?> GetRoleByIdAsync(Guid id);
        Task<Role> CreateRoleAsync(Role role);
        Task UpdateRoleAsync(Role role);
        Task DeleteRoleAsync(Guid id);
        Task<List<PermissionGroup>> GetAllPermissionsAsync();
        Task AssignPermissionsToRoleAsync(Guid roleId, List<Guid> permissionIds, List<string> permissionkeys);

        // Catálogo de Permisos (sólo SysAdmin, PermissionsAdmin.razor) -- antes esto sólo se
        // podía hacer con un script SQL a mano.
        Task<List<PermissionDefinition>> GetAllPermissionDefinitionsAsync();
        Task<PermissionDefinition> CreatePermissionAsync(PermissionDefinition permiso);
        Task UpdatePermissionAsync(PermissionDefinition permiso);
        Task<List<RoleAssignment>> GetUserRoleAssignmentsAsync();
        Task AssignRoleToUserAsync(Guid userId, Guid roleId);
        Task<List<string>> GetUserPermissionsAsync(Guid userId);

        // Sobre UserBuildingAssociation (la tabla real que lee AuthService.LoginAsync
        // para sesión/menú/permisos) — a diferencia de GetUserRoleAssignmentsAsync/
        // AssignRoleToUserAsync de arriba, que operan sobre UserRole, una tabla aparte
        // sin ningún efecto en lo que el usuario ve al loguearse.
        Task<List<UserBuildingRoleAssignment>> GetUserBuildingRoleAssignmentsAsync();
        Task AssignUserBuildingRoleAsync(Guid userId, Guid buildingId, string role, Guid approvedBy);
        Task RevokeUserBuildingRoleAsync(Guid userId, Guid buildingId, string role);
        Task AssignUnitToUserBuildingAsync(Guid userId, Guid buildingId, Guid idRole, Guid? idGroupUnit);
        Task SetUserBuildingApprovalAsync(Guid userId, Guid buildingId, Guid idRole, bool isApproved, string status, Guid approvedBy);
    }

    public class PermissionAdminService : IPermissionAdminService
    {
        private readonly IConfiguration _configuration;
        private readonly AuthService _authService;
        private readonly IPermissionService _permissionService;
        private List<PermissionDefinition> _allPermissions = new();
        private BDLayout ec { get; set; }


        public PermissionAdminService(IDbContextFactory<SpiderHoodContext> contextFactory, IConfiguration configuration, AuthService authService, IPermissionService permissionService)
        {
            _configuration = configuration;
            _authService = authService;
            _permissionService = permissionService;
            ec = new BDLayout(contextFactory);
        }

        public async Task<List<PermissionDefinition>> GetAllPermissionDefinitionsAsync()
        {
            return await ec.GetAllPermissionsAsync();
        }

        public async Task<PermissionDefinition> CreatePermissionAsync(PermissionDefinition permiso)
        {
            permiso.PermissionId = Guid.NewGuid();
            await ec.AddNewRecordAsync(permiso);
            return permiso;
        }

        public async Task UpdatePermissionAsync(PermissionDefinition permiso)
        {
            await ec.UpdateRecordAsync(permiso);
        }

        public async Task<List<Role>> GetAllRolesAsync()
        {
            List<Role> list = new();

            list = await ec.GetAllRolesAsync();

            foreach (var rol in list)
            {
                rol.Permissions = await _permissionService.GetPermissionsForRoleAsync(rol.RoleName);
            }

            return list;
        }

        public async Task<Role?> GetRoleByIdAsync(Guid id)
        {
            var role = await ec.GetRoleByIdAsync(id);
            return role.FirstOrDefault();
        }

        public async Task<Role> CreateRoleAsync(Role role)
        {
            role.IdRole = Guid.NewGuid();
            role.CreatedAt = DateTime.UtcNow;
            role.IsSystem = false;
            await ec.AddNewRecordAsync(role);
            return role;
        }

        public async Task UpdateRoleAsync(Role role)
        {
            await ec.UpdateRecordAsync(role);
        }

        public async Task DeleteRoleAsync(Guid id)
        {
            var role = await ec.GetRoleByIdAsync(id);
            var existing = role.FirstOrDefault();
            if (existing == null)
                return;

            if (existing.IsSystem)
                throw new InvalidOperationException("No se puede eliminar un rol de sistema.");

            await ec.DeleteRecordAsync(existing);
        }

        public async Task<List<PermissionGroup>> GetAllPermissionsAsync()
        {

            _allPermissions = await GetAllPermissionDefinitionsAsync();

            var groups = _allPermissions
                .GroupBy(p => p.Group)
                .Select(g => new PermissionGroup
                {
                    Module = g.Key,
                    ModuleDisplayName = GetModuleDisplayName(g.Key),
                    Icon = GetModuleIcon(g.Key),
                    Permissions = g.OrderBy(p => p.Name).ToList()
                })
                .OrderBy(g => g.ModuleDisplayName)
                .ToList();

            return groups; // Task.FromResult(groups);
        }

        public async Task AssignPermissionsToRoleAsync(Guid roleId, List<Guid> permissionIds, List<string> permissionkeys)
        {
            var role = await ec.GetRoleByIdAsync(roleId);
            if (role.FirstOrDefault() == null)
                throw new InvalidOperationException("El rol especificado no existe.");

            await ec.DeleteRolePermissionsByRoleAsync(roleId);

            foreach (var permissionId in permissionIds)
            {
                await ec.AddNewRecordAsync(new RolePermissions
                {
                    IdRole = roleId,
                    IdPermission = permissionId
                });
            }
        }

        public async Task<List<RoleAssignment>> GetUserRoleAssignmentsAsync()
        {
            var assignments = await ec.GetAllUsersWithRolesAsync();
            var roles = await ec.GetAllRolesAsync();

            foreach (var assignment in assignments)
            {
                assignment.AvailableRoles = roles;
            }

            return assignments;
        }

        public async Task AssignRoleToUserAsync(Guid userId, Guid roleId)
        {
            await ec.DeleteUserRoleByUserAsync(userId);
            await ec.AddUserRoleAsync(userId, roleId);
        }

        public async Task<List<UserBuildingRoleAssignment>> GetUserBuildingRoleAssignmentsAsync()
        {
            return await ec.GetAllUserBuildingRolesAsync();
        }

        public async Task AssignUserBuildingRoleAsync(Guid userId, Guid buildingId, string role, Guid approvedBy)
        {
            await ec.AssignUserBuildingRoleAsync(userId, buildingId, role, approvedBy);
        }

        public async Task RevokeUserBuildingRoleAsync(Guid userId, Guid buildingId, string role)
        {
            await ec.RevokeUserBuildingRoleAsync(userId, buildingId, role);
        }

        public async Task AssignUnitToUserBuildingAsync(Guid userId, Guid buildingId, Guid idRole, Guid? idGroupUnit)
        {
            await ec.AssignUnitToUserBuildingAsync(userId, buildingId, idRole, idGroupUnit);
        }

        public async Task SetUserBuildingApprovalAsync(Guid userId, Guid buildingId, Guid idRole, bool isApproved, string status, Guid approvedBy)
        {
            await ec.SetUserBuildingApprovalAsync(userId, buildingId, idRole, isApproved, status, approvedBy);
        }

        public async Task<List<string>> GetUserPermissionsAsync(Guid userId)
        {
            var role = await ec.GetRoleByUserIdAsync(userId);
            if (role == null)
                return new List<string>();

            return await _permissionService.GetPermissionsForRoleAsync(role.RoleName);
        }

        private string GetModuleDisplayName(string module)
        {
            return module switch
            {
                "dashboard" => "Dashboard",
                "building" => "Gestión de Edificios",
                "budget" => "Presupuesto y Finanzas",
                "resident" => "Portal del Residente",
                "board" => "Junta Directiva",
                "incidents" => "Incidentes y Comunicados",
                "reports" => "Reportes",
                "settings" => "Configuración",
                _ => module
            };
        }

        private string GetModuleIcon(string module)
        {
            return module switch
            {
                "dashboard" => "fas fa-chart-line",
                "building" => "fas fa-building",
                "budget" => "fas fa-file-invoice-dollar",
                "resident" => "fas fa-house-user",
                "board" => "fas fa-user-tie",
                "incidents" => "fas fa-message",
                "reports" => "fas fa-chart-pie",
                "settings" => "fas fa-gear",
                _ => "fas fa-cog"
            };
        }
    }
}